BPMS_CONFIG = {
    'server': '10.49.196.151',        # Назва вашого сервера
    'database': 'bpms_ub_mssql_dev',    # Назва бази даних
    'username': 'bpms_ub_mssql_dev',         # Логін
    'password': 'Qwwndeb_muf643',         # Пароль
    'driver': 'ODBC Driver 17 for SQL Server'  # Драйвер MSSQL
}

CAMUNDA_CONFIG = {
    'server': '10.49.196.151',        # Назва вашого сервера
    'database': 'bpms_camunda_mssql_dev',    # Назва бази даних
    'username': 'bpms_camuda_mssql_d',         # Логін
    'password': 'Wwjdn24nfn_vnj',         # Пароль
    'driver': 'ODBC Driver 17 for SQL Server'  # Драйвер MSSQL
}